###########################################################
#       Analiza i wizualizacja danych w programie R       #
#                        LabMasters                       #
#                     Piotr Ćwiakowski                    #
#                    Rozwiązania zadań                  #
###########################################################

############################################################

# Zadanie 1a. (DT)


# Zadanie 1b. (rpivotTable)


# Zadanie 2. (rbokeh)

colleges2 <- colleges[(colleges$state=="CA" | colleges$state=="MA" | colleges$state=="NY") & colleges$public=='0',]

wykresColleges1 <- figure(legend="top_left") %>%
  ly_points(grad_rate, total_cost_out, data = colleges2,
            color = state, glyph = 23, hover = "@name", size = 15, line_color = "orange") %>%
  y_axis(label="Koszty studiowania", number_formatter = "numeral") %>% # etykieta osi OY i format liczbowy
  x_axis(label = "Odsetek absolwentów") # etykieta osi OX

wykresColleges2 <- figure(legend="bottom_right") %>%
  ly_points(avg_dept, salary, data = colleges2,
            color = state, glyph = 21, hover = "@name", size = 19, line_color = "black") %>%
  y_axis(label="Oczekiwana pensja", number_formatter = "numeral") %>% # etykieta osi OY i format liczbowy
  x_axis(label = "Średni dług studenta") # etykieta osi OX

# Łączenie dwóch wykresów

# 1 row, 2 columns
grid_plot(list(wykresColleges1, wykresColleges2))


# Zadanie 3. (plotly)

# x: avg_dept - średni dług studenta w momencie ukończenia uczelni
# y: ~salary - oczekiwana pensja po 10 latach od rozpoczęcia studiów

plot_ly(colleges,  x = ~avg_dept, y = ~salary, symbol = ~public, symbols = c("square", "diamond"),
        mode = "markers",
        text = paste(~name, "<br>", "Stan: ", ~state),
        colors = "PuOr") %>%
  layout(title = 'Inwestycja w studia',
         xaxis = list(title = "Średni dług studenta",
                      titlefont = czcionka2),
         yaxis = list(title = "Oczekiwana pensja",
                      titlefont = czcionka2),
         shapes = list(list(type = 'circle',
                            xref = 'x', x0 = 13000, x1 = 30000,
                            yref = 'y', y0 = 32000, y1 = 55000,
                            fillcolor = 'rgb(60, 10, 80)', line = list(color = 'rgb(60, 10, 80)'),
                            opacity = 0.2)))

### Zadanie 4. (highcharts)

highchart() %>% 
  hc_add_series_scatter(baza2$bezrobocie, baza2$inflacja, baza2$populacja, baza2$region, baza2$name) %>%
  hc_title(text = "Krzywa Phillipsa",
           margin = 20, align = "left") %>% 
  hc_subtitle(text = "na podstawie danych z Index of Economic Freedom",
              align = "left",
              style = list(color = 'blue', fontWeight = "bold")) %>% 
  hc_credits(enabled = TRUE, # add credits
             text = "http://www.uo.uw.edu.pl/",
             href = "http://www.uo.uw.edu.pl/") %>%
  hc_xAxis(title = list(text = "Bezrobocie")) %>%
  hc_yAxis(title = list(text = "Inflacja"),opposite=TRUE) %>%
  hc_tooltip(useHTML = TRUE,
             headerFormat = "<table>",
             pointFormat = paste("<tr><th colspan=\"1\"><b>{point.label}</b></th></tr>",
                                 "<tr><th>Bezrobocie</th><td>{point.x} %</td></tr>",
                                 "<tr><th>Inflacja</th><td>{point.y} %</td></tr>",
                                 "<tr><th>Populacja</th><td>{point.z} mln</td></tr>"),
             footerFormat = "</table>")

# Zadanie 5. (dygraph)
# Na podstawie zbioru danych dotyczącego temperatur i opadów w Melbourne w latach 1981-1990
# wykonaj poniższe polecenia

# 0. Przygotowanie zbioru:
# Wczytanie bazy danych
pogoda <- read.csv("Melbourne.csv")

# W bazie znajduje się data i trzy inne zmienne: maksymalna temperatura, minimalna temperatura
# i średnie opady. Obiekt ts jest dedykowany dla baz z jedną zmienną (poza datą)
# Dlatego też w tym ćwiczeniu wykorzystamy obiekt xts
library(xts)
pogoda.xts <- xts(pogoda[,-1], as.Date(pogoda[,1], "%Y-%m-%d"))

# Często w importowanych bazach danych na końcu znajdują się problemowe wiersze nie będące obserwacjami
# Wyeliminujmy je ze zbioru:
pogoda.xts <- pogoda.xts[1:3652,]

# Ponadto zmieńmy nazwy zmiennych:
colnames(pogoda.xts) <- c("maksTemp", "minTemp", "opady")


# 1.Wybierz dane dla 1990 roku i zapisz okrojoną bazę do obiektu pogoda1990
# *Aby móc wybrać dane wiersze z objektu xts skorzystaj z funkcji time 
# (polecenie: time(pogoda.xts) to odwołanie jak do wierszy z obiektu data.frame)
# *Dane dla 1990 to obserwacje "większe" od 1989-12-31

pogoda1990 <- pogoda.xts[time(pogoda.xts)>"1989-12-31",]

# 2. Narysuj podstawowy wykres wykres za pomocą funkcji dygraph. 
# Nadaj tytuł "Pogoda w Melbourne w roku 1990". Zapisz wykres do obiektu wykresPogoda

wykresPogoda <- dygraph(pogoda1990, main="Pogoda w Melbourne w roku 1990")
wykresPogoda

# 3. Aby stworzyć bardziej czytelny wykres:
# + dodaj dodatkową oś (y2) dla opadów (dySeries: axis=)
# + przedstaw serię opady w wersji schodkowej z wypełnieniem
# + zmień kolory linii przedstawiających temperatury na odcienie czerwieni
# + dodaj etykiety osi y("Temperatura") i y2("Opady") (dyAxis)
# + zmień zakres wartości dla temperatury(0-40) i opadów (0-700) (dyAxis:valueRange)
# Nadpisz obiekt wykresPogoda z tymi zmianami.

wykresPogoda <- wykresPogoda %>%
  dySeries("opady", axis = 'y2', stepPlot = TRUE, fillGraph = TRUE, color="blue") %>%
  dySeries("maksTemp", axis = 'y', color="red") %>%
  dySeries("minTemp", axis = 'y', color="red") %>%
  dyAxis("y", label = "Temperatura", valueRange = c(0, 40)) %>%
  dyAxis("y2", label = "Opady", valueRange = c(0, 700))
wykresPogoda

# 4. Dodaj pasek umożliwiający modyfikację wyświetlanego zakresu (RangeSelector)
wykresPogoda <-wykresPogoda %>%
  dyRangeSelector()
wykresPogoda
# Nadpisz obiekt wykresPogoda z tymi zmianami.

# 5. Dodaj możliwość podświetlania danej serii (po najechaniu kursorem - dyHighlight)
# Na podstawie: https://cran.r-project.org/web/packages/dygraphs/dygraphs.pdf
# strona 10 wypróbuj dostępne opcje
wykresPogoda <- wykresPogoda %>%
  dyHighlight(highlightCircleSize = 5, 
              highlightSeriesBackgroundAlpha = 0.2,
              hideOnMouseOut = FALSE)
wykresPogoda

# Zadanie 6. (dygraph)

# Zadanie 7. (leaflet)
miasta2 <- read.csv(textConnection("
                  rank, miasto, woj, lat, long, ha
                  1, Warszawa,	mazowieckie, 52.229676, 21.012229, 51724
                  2, Kraków,	małopolskie, 50.064650, 19.94498,	32685
                  3, Szczecin,	zachodniopomorskie,	53.428544, 14.552812, 30055
                  4, Łódź,	łódzkie, 51.759248, 19.455983, 29325
                  5, Wrocław,	dolnośląskie,	51.107885, 17.038538, 29282
                  6, Zielona Góra,	lubuskie,	51.935621, 15.506186, 27832
                  7, Gdańsk,	pomorskie, 54.352025, 18.646638,	26196
                  8, Poznań,	wielkopolskie, 52.406374, 16.925168,	26191
                  9, Świnoujście,	zachodniopomorskie,	53.910033, 14.247578, 19723
                  10, Dąbrowa Górnicza,	śląskie, 50.321690, 19.194913, 18873"))

leaflet(miasta2) %>% addTiles() %>%
  addCircles(lng = ~long, lat = ~lat,
             weight=2, 
             radius = ~ha, 
             color="green", fillColor="black",
             popup = paste(miasta2$miasto, "<br>", "Ranking: ", miasta2$rank))

# Zadanie 8. (leaflet)


# Zadanie 9. (tmap)

#przygotowanie danych:
przestrzenne3<-SpatialPointsDataFrame(srodki, # Poniżej system koortdynatów które używamy:
                                      proj4string=CRS('+proj=eck4 +lon_0=0 +x_0=0 +y_0=0 +ellps=WGS84 +datum=WGS84 +units=m +no_defs +towgs84=0,0,0 '),
                                      data.frame(Indeks = baza$indeksWolnosci, # dokładne miejsce na wstawienie danych
                                                 Prawo=baza$prawo)) 

# generowanie mapy
mapWorld4 <- tm_shape(World) +
  tm_polygons("Podatki", palette="BuPu", contrast=.7, id="name", title="Wpływy podatkowe do PKB") +
  tm_shape(przestrzenne3) +
  tm_bubbles(size="Indeks", col="Prawo",
             border.col = "black", border.alpha = .5, 
             palette="Set1",labels=c('angielskie', 'francuskie', 'socjalistyczne', 'niemieckie', 'skandynawskie'),
             contrast=0.7,
             title.size="Indeks wolności gospodarczej", 
             title.col="Pochodzenie systemu prawnego", id="name") + 
  tm_style_gray() + tm_format_World()

mapWorld4
