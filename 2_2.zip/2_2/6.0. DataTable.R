###########################################################
#       Analiza i wizualizacja danych w programie R       #
#                        LabMasters                       #
#                     Piotr Ćwiakowski                    #
#                 Interaktywne tabele danych              #
###########################################################


# A. Tabela danych

# Instalacja pakietów
# install.packages("DT")

# Ustalenie ścieżki dostępu
setwd('...')

# Wczytanie bibliotek
library(DT)

# Wczytanie danych (opis bazy znajduje się w pliku 0_opis.html)
colleges <- read.csv2("colleges.csv")

### Podstawowa tabela
datatable(mtcars)

### Zmiana nazw kolumn
datatable(mtcars, colnames = c( 'model' = 1 ,'spalanie' = 2, 'cylindry' = 3, 'moc'=5),
          class="compact")  # argument class pozwala na zmianę stylu tabeli, tu wprowadzono możliwie najprostszy styl

### Podpis do tabeli
datatable(
  mtcars,
  caption = 'Tabela 1: samochody')

### Możliwe jest modyfikowanie stylu
datatable(
  head(iris),
  caption = htmltools::tags$caption(
    # funkcja htmltools::tags$caption pozwoli nam na zmianę stylu podpisu (konieczne jest użycie CSS)
    style = 'caption-side: bottom; text-align: center; color:red; font-size:200% ;',
    'Tabela ze zmienionym stylem podpisu'))

### Dodawanie filtrów z kryteriami
datatable(mtcars, filter = 'top', # argumentem filter aktywujemy kryteria pozwalające sprawnie przeszukać tabelę
          options = list(pageLength = 32, autoWidth = TRUE))


## Zadanie.
## Stwórz interaktywną tabelę danych na podstawie bazy colleges.



# B. Tabela przestawna

# instalacja pakietów
library(devtools)
install_github("ramnathv/htmlwidgets") 
install_github("smartinsightsfromdata/rpivotTable")

# Wczytanie bibliotek
library(rpivotTable)
data(mtcars)

## Wygenerowanie tabeli przestawnej
rpivotTable(mtcars, rows="gear", col="cyl", aggregatorName="Average", 
            vals="mpg", rendererName="Treemap")


