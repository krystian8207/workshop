# ---- test-a ----
1 + 1
x = rnorm(10)

# ---- test-b ----
mean(x)
sd(x)
