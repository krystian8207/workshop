###########################################################
#       Analiza i wizualizacja danych w programie R       #
#                        LabMasters                       #
#                     Piotr Ćwiakowski                    #
#           Automatyzacja raportów w R Markdown           #
###########################################################



################################################################################
# A. Funkcje renderujące w R Markdown
library(rmarkdown)
library(tidyverse)

# Renderowanie domyślnych plików:
render("7_przykład.Rmd")

# Nie działa. Błąd wskazuje na błędne kodowanie polskich znaków.
# 
# Spróbujmy czegoś innego:
render("7_przykład.Rmd", encoding = 'UTF-8')

# Obejrzyjmy wynik:
browseURL('7_przykład.html')

# Wykonajmy renderowanie w dwóch formatach:
render("7_przykład.Rmd", encoding = 'UTF-8', output_format = c("html_document", "word_document"))

# Spróbujmy automatycznie otworzyć dokument:

# Czasami działa:
browseURL('file://C:/Users/peter_c/Dropbox/6 Studia Podyplomowe/7_przykład.html')
browseURL('7_przykład.docx')

# Tak zawsze działa:
system2("open","7a_przykład.html")

################################################################################
# B. Używanie parametrów w R Markdown

# W pliku 7a_przykład.Rmd mamy zdefiniowane w YAML parametry:

# ---
# title: "Prosty Przykład"
# author: "Piotr Ćwiakowski"
# date: "15 maja 2018"
# output: html_document
# params: 
#   wojewodztwo: mazowieckie
#   data: !r as.Date("2015-01-01")
#   dane: Sklep_1.Rdata
# ---

# 1. Stała wojewodztwo
# 2. stała data - ale transformowana przez kod R na format daty (normalnie byłaby tekstem)
# 3. zmienna character z nazwą zbioru danych na których chcemy pracować

# Do stałych możemy się odwoływać tylko w chunkach (zwykłych bądź inline) i za pomocą
# listy params - która ma pola o takich samych nazwach jak parametry, w których przechowywane
# są wartości o zdefiniowane w YAML bądź podane w funkcji render()

# B.1. Definiowanie zmiennych:
rmarkdown::render("7a_przykład.Rmd", params = list(
  wojewodztwo = "małopolskie",
  data = as.Date("2015-05-19")
),
encoding = 'UTF-8')
system2("open","7a_przykład.html")

# B.2. Definiowanie bazy danych:
rmarkdown::render("7a_przykład.Rmd", params = list(
  wojewodztwo = "małopolskie",
  data = as.Date("2015-05-19"),
  dane = 'Sklep_2.Rdata'
),
encoding = 'UTF-8')
system2("open","7a_przykład.html")

# Mamy raport na podstawie zupełnie innego pliku!!!!

###
# B.3. Możemy również ręcznie (przez interfejs graficzny) wprowadzać parametry:
rmarkdown::render("7a_przykład.Rmd", 
                  params = 'ask',
                  encoding = 'UTF-8')
# (pamiętajmy, że jeśli rezygnujemy, to trzeba nacisnąć przycisk "stop" na górnej krawędzi konsoli w RStudio)

# Otwiera to drogę do wykorzystania widgetów shiny. Uruchommy przykład 
# 7b_przykład.Rmd a następnie otwórzmy plik markdown w celu zrozumienia parametrów.

# Poniżej zamieszczam listę parametrów i linki do widgetów, gdzie znajduje się ich  i opis argumentów
# Parametr województwo, widget select: http://shiny.rstudio.com/reference/shiny/latest/selectInput.html
# Parametr dane, widget fileinput: http://shiny.rstudio.com/reference/shiny/latest/fileInput.html
# Parametr data, widget dateinput: http://shiny.rstudio.com/reference/shiny/latest/dateInput.html
# Parametr x1, widget slider: http://shiny.rstudio.com/reference/shiny/latest/sliderInput.html
# Parametr x2, widget checkbox: http://shiny.rstudio.com/reference/shiny/latest/numericInput.html
# Parametr x3, widget radioButtons: http://shiny.rstudio.com/reference/shiny/latest/radioButtons.html

rmarkdown::render("7b_przykład.Rmd", 
                  params = 'ask',
                  encoding = 'UTF-8')

system2("open","7b_przykład.html")

# Ćwiczenia.
# 
# 1. Dokonaj parametryzacji swojego raportu i przetestuj ich działanie za pomocą funkcji render()
# 
# 2. Dokonaj parametryzacji swojego raportu za pomocą widgetów.
# 
# 3. Napisz pętlę, która wygeneruje raport dla każdej z baz danych Sklep_1, Sklep_2, ... , Sklep_24 w folderze z danymi.



# Składanie kilku plików Rmd w całość.
