###########################################################
#       Analiza i wizualizacja danych w programie R       #
#                        LabMasters                       #
#                     Piotr Ćwiakowski                    #
#                      pakiet plotly                      #
###########################################################


# Instalacja pakietów
# install.packages('plotly')
# install.packages('RColorBrewer')

# Wczytanie bibliotek
library(plotly)
library(RColorBrewer)

# Ustalenie ścieżki dostępu
setwd('...')

# Wczytanie danych (opis bazy znajduje się w pliku 0_opis.html)
colleges <- read.csv2("colleges.csv", stringsAsFactors = F)

# Przygotowanie zmiennej
colleges$public <- factor(colleges$public, levels=c(0, 1), labels=c('private', 'public'))

# Podstawowy wykres
d <- plot_ly(colleges, x = ~admit_rate, y = ~salary, mode = "markers")
d

# Mapowanie zmiennej grad_rate jako koloru
d <- plot_ly(colleges,  x = ~admit_rate, y = ~salary, 
             color = ~grad_rate, mode = "markers"
             )
d

# Edycja wyświetlanego tekstu  
d <- plot_ly(colleges,  x = ~admit_rate, y = ~salary, color = ~grad_rate, mode = "markers",
              text = paste(colleges$name, "<br>", "Odsetek absolwentów: ", colleges$grad_rate))
d



d <- layout(d, title = 'Zaznaczenie dwóch obszarów', 
            shapes = list(
              list(type = 'circle',
                   xref = 'x', x0 = 45, x1 = 90,
                   yref = 'y', y0 = 30000, y1 = 60000,
                   fillcolor = 'rgb(50, 20, 90)', line = list(color = 'rgb(50, 20, 90)'),
                   opacity = 0.2),
              list(type = 'circle',
                   xref = 'x', x0 = 0, x1 = 45,
                   yref = 'y', y0 = 55000, y1 = 80000,
                   fillcolor = 'rgb(90, 200, 75)', line = list(color = 'rgb(90, 200, 75)'),
                   opacity = 0.2)))
d

# Edycja wizualna
czcionka <- list(
  family = "Courier New, monospace",
  size = 15,
  color = "purple")

p <- plot_ly(colleges,  x = ~admit_rate, y = ~salary, color = ~grad_rate, mode = "markers",
        text = paste(colleges$name, "<br>", "Odsetek absolwentów: ", ~grad_rate),
        colors = "PuOr", 
        showlegend = F) %>%
  layout(xaxis = list(
                      title = "Wskaźnik przyjęć",
                      titlefont = czcionka),
         yaxis = list(
                      title = "Oczekiwana pensja",
                      titlefont = czcionka))
p

# Wykres pudełkowy
p <- plot_ly(colleges, x = ~salary, color = ~public, type = "box")
p


### Wykres kołowy
ds <- data.frame(labels = c("A", "B", "C"),
                 values = c(10, 40, 60))  # stworzenie data-frame

plot_ly(ds, labels = ~labels, values = ~values, type = "pie") %>%
  layout(title = "Wykres kolowy")

### Wykres kołowy bez środka
plot_ly(ds, labels = ~labels, values = ~values, type = "pie", hole = 0.6, showlegend = F) %>%
  layout(title = "Wykres bez srodka")

## Plotly a ggplot2
library(ggplot2)
data(diamonds)

### Wykres słupkowy
p <- ggplot(data = diamonds, aes(x = cut, fill = clarity)) +
  geom_bar(position = "dodge") #arggumenty analogiczne do tych, używanych w pakiecie ggplot2
p
ggplotly(p)

# Wiecej informacji tutaj:
# https://plot.ly/feed/

