###########################################################
#       Analiza i wizualizacja danych w programie R       #
#                        LabMasters                       #
#                     Piotr Ćwiakowski                    #
#                 pakiet  MetricsGraphics                 #
###########################################################


##

# instalacja bibliotek
# install.packages("metricsgraphics")
# install.packages('RcolorBrewer')

# Wczytanie biblioteki
library(metricsgraphics)
library(RColorBrewer)

# Biblioteka MetricsGraphics umożliwia unikanie tworzenie jednej gigantycznej funkcji z ogromną ilością parametrów. 
# W przeciwieństwie do ggplot2 niemożliwe jest natomiast łączenie różnych geometrii na jednym wykresie.

### Podstawowy wykres liniowy
tmp <- data.frame(year=seq(1790, 1970, 10), uspop=as.numeric(uspop)) # dane o populacji USA w latach 1790-1970
tmp %>%
  mjs_plot(x=year, y=uspop) # podstawowa funkcja inicjująca wykres

### Podstawowy wykres słupkowy

tmp %>%
  mjs_plot(x=uspop, y=year, width=500, height=400) %>%
  mjs_bar()  # funkcja określająca typ wykresu

### Wykres punktowy

mtcars %>% # baza, z której pochodzić będą punkty
  mjs_plot(x=wt, y=mpg, width=600, height=500) %>%
  mjs_point(color_accessor=carb, size_accessor=carb)%>% #wielkość i kolor punktów w zależności od zmiennej carb
  mjs_labs(x="Masa samochodu", y="Spalanie") #podpisy osi

### Rozbudowany wykres punktowy

mtcars %>%
  mjs_plot(x=wt, y=mpg, width=1000, height=800) %>%
  mjs_point(color_accessor=cyl,
            x_rug=TRUE, y_rug=TRUE, # zaznaczenie rzutów punktów na osie
            size_accessor=carb,
            size_range=c(5, 10),  #  zmiana zakresu wielkości punktów
            color_type="category", # umożliwienie dyskretnego podziału kolorów
            color_range=brewer.pal(n=11, name="RdBu")[c(1, 5, 11)]) %>%
  mjs_labs(x="Masa", y="Spalanie")


# Wykres punktowy
library(metricsgraphics)
library(RColorBrewer)

colleges2 <- read.csv2("colleges.csv", stringsAsFactors = F)

colleges2 %>% 
  mjs_plot(x=admit_rate, y=salary) %>%
  mjs_point(color_accessor=avg_dept,
            size_accessor=avg_dept) %>%
  mjs_labs(x="Wskaźnik przyjęć", y="Oczekiwana pensja")

# Wykres liniowy
library(metricsgraphics)

baza2 <- read.csv('State.csv',header=T,dec=".",sep=',',stringsAsFactors = FALSE)

baza2 %>% # baza, z której pochodzić będą punkty
  mjs_plot(title="Podatki a ustrój państwa", x=podatki, y=podatekDochodowy) %>%
  mjs_point(color_accessor=ustroj, size_accessor=ustroj)%>% #wielkość i kolor punktów w zależności od zmiennej polity2_
  mjs_labs(x="Wpływy podatkowe do PKB", y="Stawka podatku dochodowego") %>% #podpisy osi
  mjs_add_legend(legend=c('a','b','c'))

# Więcej informacji
# https://hrbrmstr.github.io/metricsgraphics/
