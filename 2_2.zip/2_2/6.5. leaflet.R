###########################################################
#       Analiza i wizualizacja danych w programie R       #
#                        LabMasters                       #
#                     Piotr Ćwiakowski                    #
#                     pakiet  leaflet                     #
###########################################################

# Instalacja pakietów
# install.packages("leaflet")
# install.packages('dplyr')
# install.packages('tidyr')

# Wczytanie bibliotek
library(dplyr)
library(tidyr)
library(leaflet)

# Ścieżka dostępu
setwd('...')

# Wczytanie i przygotowanie danych


# Leaflet
# Pojedynczy punkt na mapie
wykres1 <- leaflet() %>%
  addTiles() %>%  # dodanie domyślnej mapy
  addMarkers(lng=21.018766, lat=52.240385, popup="Uniwersytet Warszawski")
  # dodanie w określonym miejscu znacznika z napisem
wykres1

# czarno-biały styl
wykres2 <- leaflet() %>%
  addTiles() %>%  # dodanie domyślnej mapy
  addMarkers(lng=21.018766, lat=52.240385, popup="Uniwersytet Warszawski")%>% 
  addProviderTiles("Stamen.Toner")
  # dodanie w określonym miejscu znacznika z napisem
wykres2

# stonowany styl
wykres3 <- leaflet() %>%
  addTiles() %>%  # dodanie domyślnej mapy
  addMarkers(lng=21.018766, lat=52.240385, popup="Uniwersytet Warszawski")%>% 
  addProviderTiles("CartoDB.Positron")
  # dodanie w określonym miejscu znacznika z napisem
wykres3

# Zaznaczenie obszaru na mapie (teren Kampusu UW)
leaflet() %>% addTiles() %>%
  addRectangles(
    lng1=21.016034, lat1=52.241554,
    lng2=21.021772, lat2=52.238760, #współrzędne przeciwległych narożników
    fillColor = "transparent"
  )%>% 
  addProviderTiles("CartoDB.Positron")

# Wstawianie obrazów na mapę
warszawa <- makeIcon(
  iconUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b5/POL_Warszawa_COA.svg/2000px-POL_Warszawa_COA.svg.png",
  iconWidth = 50, iconHeight = 80  # wymiary 
  )
krakow <- makeIcon(
  iconUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/POL_Krak%C3%B3w_COA.svg/2000px-POL_Krak%C3%B3w_COA.svg.png",
  iconWidth = 50, iconHeight = 80
  )
lodz <- makeIcon(
  iconUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/POL_%C5%81%C3%B3d%C5%BA_COA.svg/2000px-POL_%C5%81%C3%B3d%C5%BA_COA.svg.png",
  iconWidth = 50, iconHeight = 60 
  )
leaflet() %>% addTiles() %>%
  addMarkers(lng=21.012229, lat=52.229676, popup="Warszawa",icon = warszawa) %>%
  addMarkers(lng=19.94498, lat=50.064650, popup="Kraków",icon = krakow) %>%
  addMarkers(lng=19.455983, lat=51.759248, popup="Łódź",icon = lodz)

# Punkty na mapie
# Największe miasta według liczby ludnosci
miasta <- read.csv(textConnection("
                  miasto, woj, lat, long, pop
                  Warszawa,	mazowieckie, 52.229676, 21.012229, 1744351
                  Kraków,	małopolskie, 50.064650, 19.94498, 761069
                  Łódź,	łódzkie, 51.759248, 19.455983, 700982
                  Wrocław, dolnośląskie, 51.107885, 17.038538, 635759
                  Poznań,	wielkopolskie, 52.406374, 16.925168, 542348
                  Gdańsk,	pomorskie, 54.352025, 18.646638, 462249
                  Szczecin,	zachodniopomorskie,	53.428544, 14.552812, 405657
                  Bydgoszcz, kujawsko-pomorskie, 53.123480, 18.008438, 355645
                  Lublin, lubelskie, 51.246454, 22.568446, 340727
                  Katowice,	śląskie, 50.264892, 19.023782, 299910")) #  odczytanie stworzenego pliku csv

# leaflet z zaznaczonymi miastami
leaflet(miasta) %>% addTiles() %>%
  addCircles(lng = ~long, lat = ~lat,
             weight=4, # grubość 'obręczy'
             radius=10000, # wielkość punktów
             popup = ~miasto) # wyświetlana etykieta 

# zmapowanie populacji
leaflet(miasta) %>% addTiles() %>%
  addCircles(lng = ~long, lat = ~lat,
             weight=2, # grubość 'obręczy'
             radius= ~pop, # wielkość punktów
             popup = ~miasto) # wyświetlana etykieta

# utworzone punkty są zbyt duże. Aby zachować mapowanie zmiennej i dostosowując obraz
# od strony wizualnej znormalizujmy zmienną pop

miasta$norm <- (miasta$pop-mean(miasta$pop))/sd(miasta$pop)

leaflet(miasta) %>% addTiles() %>%
  addCircles(lng = ~long, lat = ~lat,
             weight=2, # grubość 'obręczy'
             radius = ~pop/100, # mapowania populacji jako wielkości punktów
                                # podzielenie przez 100 dla widocznego mapowania
             popup = ~miasto) 
 

# Dodanie bardziej złożonej etykiety
leaflet(miasta) %>% addTiles() %>%
  addCircles(lng = ~long, lat = ~lat,
             weight=2, # grubość 'obręczy'
             radius = ~pop/100, # mapowania populacji jako wielkości punktów
             popup = paste(miasta$miasto, "<br>", "Populacja:", miasta$pop)) # Etykieta
                      # paste - złączenie tesktu
                      # 1. wartość zmiennej miasto
                      # 2. enter
                      # 3. napis: "Populacja:"
                      # 4, wartość zmiennej pop

# Zmiana koloru punktów
leaflet(miasta) %>% addTiles() %>%
  addCircles(lng = ~long, lat = ~lat,
             weight=2, # grubość 'obręczy'
             radius = ~pop/100, # mapowania populacji jako wielkości punktów
             color="red", fillColor="yellow",
             popup = paste(miasta$miasto, "<br>", miasta$woj, "<br>", "Populacja:", miasta$pop)) # Etykieta
