###########################################################
#       Analiza i wizualizacja danych w programie R       #
#                        LabMasters                       #
#                     Piotr Ćwiakowski                    #
#                     pakiet  dygraph                     #
###########################################################

# Instalacja pakietów
# install.packages("dygraphs")
# install.packages('dplyr')
# install.packages('tidyr')

# Wczytanie bibliotek
library(dplyr)
library(tidyr)
library(dygraphs)

# Ścieżka dostępu
setwd('...')

# Wczytanie i przygotowanie danych
plamy <- read.csv("Plamy sloneczne.csv")

# Deklaracja jako szereg czasowy (Time Series)
plamy <- ts(plamy[,1], start=1700, end=1988, frequency=1) # wybór pierwszej (tu jedynej) zmiennej
                                                        # ze zbioru danych, dane są od 1700 
                                                        # do 1988 roku z odstępem 1 roku 
# R=(10g+p)k, gdzie g-liczba grup plam, p–liczba plam, a k to ich wielkość

# Podstawowy wykres
dygraph(plamy)

# Aby "przybliżyć" wykres (zmniejszyć wyświetlany zakres) należy zaznaczyć
# dany obszar w dowolnym miejscu na obszarze wykresu.
# Powrót do wyjściowego widoku możliwy jest poprzez dwukrotne kliknięcie na obszarze wykresu

# EDYCJA WIZUALNA
wykresPlamy <- dygraph(plamy, main="Liczba plam słonecznych") %>% # dodanie tytułu wykresu
                  dyAxis("y", label = "Liczba Wolfa", valueRange = c(0, 250)) %>% # etykieta osi OY; zakres wartości osi OY
                  dyAxis("x", drawGrid = FALSE) %>% # brak wyświetlania pionowych linii siatki (oś OX)
                  dyOptions(includeZero = TRUE, # upewnienie, że zakres wartości będzie zawierał zero
                            axisLineColor = "peru", # kolor osi wykresu
                            gridLineColor = "salmon", # kolor siatki wykresu
                            colors="#18183d") # kolor serii
wykresPlamy
# Poprzez "wykresPlamy <-" zapisaliśmy zedytowany wykres do obiektu. 
# Umożliwi to jego łatwe modyfikowanie w drugiej części.

# EDYCJA SERII I FUNKCJONALNOŚCI

# Wypełnienie serii
wykresPlamy %>%
  dyOptions(fillGraph = TRUE, fillAlpha = 0.2)

# Zaznaczenie punktów
wykresPlamy %>%
  dyOptions(drawPoints = TRUE, pointSize = 1.5)

# W wersji schodkowej
wykresPlamy %>%
  dyOptions(stepPlot = TRUE)

# *Powyższe zmiany można także wprowadzić z użyciem polecenia dySeries zamiast dyOptions
# Na przykład
wykresPlamy %>%
  dySeries("V1", stepPlot = TRUE, fillGraph = TRUE)
# (rozróżnienie tych dwóch poleceń nabiera kluczowego znaczenia przy przedstawianiu wielu
# serii na jednym wykresie. Wtedy użycie polecenia dySeries umożliwia osobną edycję każdej serii)

# Nazwa serii 
wykresPlamy %>%
  dySeries("V1", label="Plamy słoneczne")

# Linia serii
wykresPlamy %>%
  dySeries("V1", strokePattern = "dashed", strokeWidth = 1.5) # przerywana + pogrubienie
wykresPlamy %>%
  dySeries("V1", strokePattern = "dotted") # kropkowana
wykresPlamy %>%
  dySeries("V1", strokePattern = "dotdash") # kropkowano-przerywana
                                            # domyślnie solid

# Legenda
wykresPlamy %>%
  dySeries("V1", label="Plamy słoneczne")  %>%
  dyLegend(show = "always", hideOnMouseOut = FALSE) # legenda zawsze widoczna i
                                                    # wyświetlanie w legendzie wartości nawet pomimo
                                                    # braku kursora na obszarze wykresu
wykresPlamy %>%
  dySeries("V1", label="Plamy słoneczne")  %>%
  dyLegend(show = "follow") # legenda wyświetlana przy punkcie
                            # inne: "auto", "always", "onmouseover", "never"

# Pasek umożliwiający zaznacznie wyświetlanego zakresu
wykresPlamy %>%
  dyRangeSelector()

# Cieniowanie
# Na podstawie obserwowanej liczby plam słonecznych naukowcy wyróżnili okresy
# oznaczające wzmożoną bądź nikłą aktywność słoneczną
# Minimum Maundera: 1645-1717
# Minimum Daltona: 1790-1830
# Maksimum współczesne: 1914-2000
# Zaznaczenie tych okresów na wykresie za pomocą cieniowania można wykonać następująco:
wykresPlamy2<-wykresPlamy %>%
  dyShading(from = "1700-1-1", to = "1717-1-1", color="#b6d0fc") %>%
  dyShading(from = "1790-1-1", to = "1830-1-1", color="#b6d0fc") %>%
  dyShading(from = "1914-1-1", to = "1988-1-1", color="#ffcccc")
wykresPlamy2
# Można także zaznaczyć linie odpowiadające danemu punktowi na osi OX bądź OY dzięki 
# poleceniu dyEvent
# Na przykład:
wykresPlamy2 %>%
  dyEvent("1717-1-1", "Minimum Maudera", labelLoc = "top") %>%
  dyEvent("1790-1-1", "") %>%
  dyEvent("1830-1-1", "Minimum Daltona", labelLoc = "top") %>%
  dyEvent("1914-1-1", "") %>%
  dyEvent("1988-1-1", "Maksimum współczesne", labelLoc = "top")

# Alternatywnie możemy dodać tekst (adnotację) np. w "środkach" okresów
wykresPlamy2 %>%
  dyAnnotation("1710-1-1", text = "A", tooltip = "Minimum Maudera") %>%
  dyAnnotation("1815-1-1", text = "B", tooltip = "Minimum Daltona") %>%
  dyAnnotation("1951-1-1", text = "C", tooltip = "Maksimum współczesne")

# ***DODATKOWO
# Gdy spróbujemy dodać np. napis "Minimum Maudera" zamiast "A"
# (aby nazwy okresów były wyswietlone cały czas (bez konieczności "najechania na punkty A, B, C))
# Okazuje się, że nie zostanie on wyświetlony poprawnie (przewidziane miejsce jest za małe):
wykresPlamy2 %>%
  dyAnnotation("1710-1-1", text = "Minimum Maudera", tooltip = "Minimum Maudera")

# Zwiększmy domyślne pole na tekst
wykresPlamy2 %>%
  dyAnnotation("1710-1-1", text = "Minimum Maudera", width = 80, height = 35) %>%
  dyAnnotation("1815-1-1", text = "Minimum Daltona", width = 80, height = 35) %>%
  dyAnnotation("1951-1-1", text = "Maksimum współczesne", width = 80, height = 35)

# Alternatywnie możemy napisać własną funkcję umożliwiającą dodanie dłuższej adnotacji: 
presAnnotation <- function(dygraph, x, text) {
  dygraph %>%
    dyAnnotation(x, text, attachAtBottom = TRUE, width = 80, height = 35)
}

wykresPlamy2 %>%
  presAnnotation("1710-1-1", text = "Minimum Maudera") %>%
  presAnnotation("1815-1-1", text = "Minimum Daltona") %>%
  presAnnotation("1951-1-1", text = "Maksimum współczesne")


# Gdzie można znaleźć więcej?
# https://rstudio.github.io/dygraphs/index.html


################################################################################
# Dane podatkowe - case study

tax <- read.csv('taxRevenue.csv')

# Instalacja pakietów - szeregi czasowe
install.packages('zoo')
install.packages('xts')

# Wczytanie bibliotek
library(zoo)
library(xts)

tax2 <- tax %>% select(Croatia, France, Mauritius,United.Kingdom, South.Africa)


# Szeregi podatkowe
tax.xts <- xts(tax2, as.Date(paste(tax[,1], 1, 1, sep = "-")))

### Dodawanie tytułów osi i tytułu wykresu

dygraph(tax.xts, 
        main = "Podatki w relacji do PKB - wybrane kraje", 
        ylab = "% PKB")

### Rozbudowany wykres
d1 <- dygraph(tax.xts) %>%
      dySeries("France", label = "Francja", color = "red") %>%   
      dySeries("Mauritius", label = "Mauritius", color = "#2222bb") %>% 
      dySeries("United.Kingdom", label = "Wlk. Bryt.", color = "blue") %>%
      dySeries("South.Africa", label = "RPA", color = "tomato4") %>%  
      dySeries("Croatia", label = "Chorwacja", color = "magenta") 
d1

# Wykres typu stacked 
d1 %>%  
  dyOptions(stackedGraph = TRUE) %>%                           
  dyRangeSelector(height = 20)


### Włączenie oznaczeń punktów
d1 %>%
  dyOptions(drawPoints = TRUE, pointSize = 2)


# Dzięki funkcji `dyHighlight` możemy zmieniać opcje wyróżnienia serii danych podczas wskazania ich przez kursor.
d1 %>%
  dyHighlight(highlightCircleSize = 5, 
              highlightSeriesBackgroundAlpha = 0.2,
              hideOnMouseOut = FALSE)

# Możliwe jest również pogrubianie serii wyróżnianej:
d1 %>% dyHighlight(highlightSeriesOpts = list(strokeWidth = 3))

