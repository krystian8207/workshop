###########################################################
#       Analiza i wizualizacja danych w programie R       #
#                        LabMasters                       #
#                     Piotr Ćwiakowski                    #
#                      pakiet rbokeh                      #
###########################################################


# Instalacja pakietów
# install.packages("rbokeh")
# install.packages('dplyr')
# install.packages('tidyr')

# Ustalenie ścieżki dostępu
setwd('...')

# Wczytanie bibliotek
library(rbokeh)
library(dplyr)

# Wczytanie danych (opis bazy znajduje się w pliku 0_opis.html)
colleges <- read.csv2("colleges.csv")

#########################################################################
# Pakiet rbokeh umożliwia tworzenie wizualizacji podobnie jak w ggplot2.
# Zadaniem będzie zwizualizowanie statystyk warunków oferowanych 
# studentom przez różne amerykańskie uczelnie.
#########################################################################

# Tworzenie wykresu rozpocznijmy poleceniem figure()
wykresColleges <- figure()

# Wywołanie pustego obiektu:
wykresColleges

# Sprawdźmy czy duże zainteresowanie daną uczelnią świadczy o wyższych zarobkach jej 
# absolwentów. Przedstawimy wykres zależności między oczekiwaną pensją po 10 latach 
# od rozpoczęcia studiów (salary) a wskaźnikiem przyjęć (jaki odsetek spośród 
# aplikujących zostaje przyjętych) (admit_rate)

# Do stworzenia serii danych (punktowej) należy użyć polecenia ly_points
# ly_points(zmienna na osi x, zmienna na osi y, zbiór danych)
wykresColleges <- figure() %>%
  ly_points(admit_rate, salary, data = colleges)
wykresColleges

# Przedstawiona zależność wydaje się odpowiadać intuicji:
# im mniejsze (w stosunku do przyjętych) zainteresowanie aplikacją na daną uczelnie
# tym mniejsze zarobki jej absolwentów (a zatem i oczekiwania zarobkowe - mamy
# selekcje do próby) 

# Tego rodzaju wizualizacje umożliwiają mapowanie więcej niż dwóch zmiennych:
# poprzez przedstawienie wartości zmiennych z użyciem koloru, wielkości punktów, 
# ich kształtu zmapujmy zmienną binarną public oznaczającą czy dana uczelnia jest 
# publiczna czy prywatna:
wykresColleges <- figure() %>%
  ly_points(admit_rate, salary, data = colleges,
            color = public)
wykresColleges

# Okazuje się, że zmienna ta domyślnie na wykresie została zinterpretowana jako 
# ciągła (a nie zerojedynkowa). 

class(colleges$public) # wartości klasy integer

# Zmieńmy klasę zmiennej na factor 
colleges$public <- as.factor(colleges$public)

# I ponownie wykres już w poprawnej formie:
wykresColleges <- figure() %>%
  ly_points(admit_rate, salary, data = colleges,
            color = public)
wykresColleges

# Do bardziej widocznego rozróżnienia czy dana uczelnia jest publiczna możemy 
# dodać różne kształty (mozna także zmapować w ten sposób czwartą zmienną)
wykresColleges <- figure() %>%
  ly_points(admit_rate, salary, data = colleges,
            color = public, glyph = public)
wykresColleges

# Dodatkowo możemy nadać interaktywny charakter ("najechanie" na punkt umożliwi 
# wyświetlenie informacji o wartości danej zmiennej dla punktu)
# Dodajmy informację o nazwie uczelni oraz wartości zmiennej salary i admit_rate
wykresColleges <- figure() %>%
  ly_points(admit_rate, salary, data = colleges,
            color = public, glyph = public, 
            hover = list(name, admit_rate, salary))
wykresColleges

# Można także dodać tekst wyswietlany po najechaniu kursorem wraz z wartością zmiennej
wykresColleges <- figure() %>%
  ly_points(admit_rate, salary, data = colleges,
            color = public, glyph = public, 
            hover = "Oczekiwana pensja po ukończeniu @name to @salary $")
wykresColleges

# Dodanie linii regresji
reg <- lm(salary ~ admit_rate, data = colleges) # regresja liniowa
wykresColleges <- figure() %>%
  ly_points(admit_rate, salary, data = colleges,
            color = public, glyph = public, 
            hover = "Oczekiwana pensja po ukończeniu @name to @salary $") %>%
  ly_abline(reg, type = 2, legend = "linia regresji", color = 'blue', width=3)
wykresColleges

# Przykładowy histogram
wykresColleges <- figure() %>%
  ly_hist(colleges$admit_rate)
wykresColleges


# EDYCJA WIZUALNA

# Znaczniki
# uruchomienie funkcji point_types() umożliwia wyświetlenie dostępnych kształtów,
# znaczników i przyporządkowanych im numerów/nazw
point_types()

# Wprowadźmy znacznik w kształcie wypełnionego trójkąta (triangle)
wykresColleges <- figure() %>%
  ly_points(admit_rate, salary, data = colleges,
            color = public, glyph = "triangle", 
            hover = "Oczekiwana pensja po ukończeniu @name to @salary $")
wykresColleges

# Możemy także dostosowywać wielkość wykresu (szczególnie przydatne przy tworzeniu plików html)
wykresColleges <- figure(width = 600, height = 600) %>%
  ly_points(admit_rate, salary, data = colleges,
            color = public, glyph = "triangle", 
            hover = "Oczekiwana pensja po ukończeniu @name to @salary $")
wykresColleges

# Zmiana koloru i rozmiaru punktów
wykresColleges <- figure() %>%
  ly_points(admit_rate, salary, data = colleges,
            color = "orange", size = 15)
wykresColleges

wykresColleges <- figure() %>%
  ly_points(admit_rate, salary, data = colleges,
            fill_color = "orange", line_color = "red")
wykresColleges

# paleta: inny odcień dla każdej obserwacji
n <- nrow(colleges) # liczba obserwacji w zbiorze colleges
paleta <- colorRampPalette(c("violet", "blue"))(n) # tyle odcieni ile obserwacji

wykresColleges <- figure() %>%
  ly_points(admit_rate, salary, data = colleges, color = paleta,
  hover = "Oczekiwana pensja po ukończeniu @name to @salary $")
wykresColleges

# Inne atrybuty:
# fill_alpha	przezroczystość wypełnienia (0 - przezroczysty; 1-pełny kolor)
# line_width	grubość linii (kontur punktów)
# line_alpha	przezroczystość linii (0 - przezroczysty; 1-pełny kolor)
# line_dash	linia ('solid' - ciągła; 'dashed'-przerywana; 'dotted'-kropkowana;
  # 'dotdash' - linia kropka-kreska; 'dashdot' - linia kreska-kropka)

# Edycja osi i legendy
wykresColleges <- figure() %>%
  ly_points(admit_rate, salary,
            color=public, data = colleges) %>%
  y_axis(label="Oczekiwana pensja", number_formatter = "numeral") %>% # etykieta osi OY i format liczbowy
  x_axis(label = "Wskaźnik przyjęć") # etykieta osi OX
wykresColleges

# Pasek narzędzi
wykresColleges <- figure(toolbar_location="right") %>%
  ly_points(admit_rate, salary, data = colleges) 
wykresColleges
# Inne opcje: above, below, left

# 1. Położenie legendy
# Zmiana legend_location jako opcja figure:
wykresColleges <- figure(legend_location ="top_left") %>%
  ly_points(admit_rate, salary, color = public, data = colleges) 
wykresColleges


# 2. Tekst w legendzie

# Mamy takie opcje:
#   
#   - legenda do jednej serii punktowej (żeby zaprezentować, że można zmienić, 
#   ale taka legenda niewiele mówi)
wykresColleges <- figure() %>%
  ly_points(admit_rate, salary, legend = "Seria1", data = colleges) 
wykresColleges

# - punktowy + np. z linią regresji:
  
  regresja <- lm(salary ~ admit_rate, data = colleges)
wykresColleges <- figure() %>%
  ly_points(admit_rate, salary, legend = "Wartości", data = colleges) %>%
  ly_abline(regresja, type = 2, legend = "Linia regresji")
wykresColleges

# Poniżej wyjaśnienie dlaczego tak się ograniczamy:

# legenda jest dostosowana do modyfikacji wykresów, na których jest kilka 
# różnego rodzaju serii (ly_*) tzn gdy mamy np punkty na to nałożoną linię 
# to możemy zmienić etykietę tej serii np.
z <- lm(dist ~ speed, data = cars)
figure(width = 600, height = 600) %>%
  ly_points(cars, hover = cars, legend = "data") %>%
  ly_lines(lowess(cars), legend = "lowess") %>%
  ly_abline(z, type = 2, legend = "lm")

# Ale jak chcemy dodać poprostu legend =" " przy takich wykresach jak tam są to 
# krzyczy, że już automatycznie legenda została dodana (bo faktycznie jest) i 
# nie rozumie, że my chcemy tylko modyfikować jej tytuł. Np.

wykresColleges <- figure() %>%
  ly_points(admit_rate, salary, data = colleges, color = "blue") %>%
  ly_points(admit_rate, avg_dept, data = colleges, color = "orange") %>%
  ly_points(admit_rate, total_cost_in, data = colleges, color = "purple")   
wykresColleges 

# No i ok - rysuje się więc można dorzucić te legendy:
  
wykresColleges <- figure() %>%
  ly_points(admit_rate, salary, data = colleges, color = "blue", legend = "pensja") %>%
  ly_points(admit_rate, avg_dept, data = colleges, color = "orange", legend = "średni dług po studiach") %>%
  ly_points(admit_rate, total_cost_in, data = colleges, color = "purple", legend = "koszty podjęcia studiów")   
wykresColleges  

# Ale to powoduje błędy. można  zostawić samą legendę, ale:
wykresColleges <- figure() %>%
  ly_points(admit_rate, salary, data = colleges, legend = "pensja") %>%
  ly_points(admit_rate, avg_dept, data = colleges, legend = "średni dług po studiach") %>%
  ly_points(admit_rate, total_cost_in, data = colleges, legend = "koszty podjęcia studiów")   
wykresColleges 

####################
## Inny przykład
cars <- cars %>% mutate(przekroczyl=ifelse(speed>15,"zostala","nie zostala"))  
# stworzenie dodatkowej zmiennej (pakiet dplyr) 
z <- lm(dist ~ speed, data = cars) # regresja liniowa
n <- nrow(cars)
ramp <- colorRampPalette(c("blue", "red"))(n) #stworzenie spektrum kolorów
figure(width = 700, height = 500, xlab = 'Prędkość', ylab = 'Odległość', toolbar_location = "below") %>%
  # zmiana lokalizacji paska narzędzi
  ly_points(speed, dist, cars, color = ramp, size = speed, hover = "@speed mph,
            dozwolona prędkość @przekroczyl przekroczona", glyph = 15)%>%
  ly_abline(z, type = 2, legend = "lm",color = 'orange',width=3)%>%
  ly_lines(lowess(cars), legend = "lowess",width=3) # inny sposób szacowania zależości
