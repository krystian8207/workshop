###########################################################
#       Analiza i wizualizacja danych w programie R       #
#                        LabMasters                       #
#                     Piotr Ćwiakowski                    #
#                    pakiet  highcharts                   #
###########################################################


# Instalacja pakietów
# install.packages("highcharter")
# install.packages('dplyr')
# install.packages('tidyr')
# install.packages("lazyeval")

# Wczytanie bibliotek
library(dplyr)
library(tidyr)
library(highcharter)
library(lazyeval)

# Ścieżka dostępu
setwd('...')

# Wczytanie i przygotowanie danych
baza2 <- read.csv('State.csv', stringsAsFactors = FALSE)
baza2 <- baza2[complete.cases(baza2),]

## Wykresy bąbelkowe

# Wygenerowanie podstawowego wykresu 
highchart() %>% # podstawowy wykres
  hc_title(text = "Krzywa Phillipsa") %>% # dodanie tytułu
  hc_add_series_scatter(baza2$inflacja, baza2$bezrobocie) # dodanie serii danych

### Dodatkowa zmienna jako rozmiar punktów

# Dodanie mapowania populacji jako rozmiar punktów:
highchart() %>% 
  hc_title(text = "Krzywa Phillipsa") %>% 
  hc_add_series_scatter(baza2$bezrobocie, baza2$inflacja, baza2$populacja)

### Dodanie kilku serii (kolory punktów)

hc <- highchart()
# pętla, w której dodawane są kolejne serie - Regiony
for (R in unique(baza2$region)) { # uruchomienie pętli (dla każdego regionu)
  hc <- hc %>% # osobne serie dla każdego regionu
    hc_add_series_scatter(baza2$bezrobocie[baza2$region==R], 
                         baza2$inflacja[baza2$region==R],
                         baza2$populacja[baza2$region==R],
                         name = sprintf("Region: %s", R), # %s: string (konwersja poszczególnych
                                                          # wartości zmiennej Region na tekst)
                         showInLegend = TRUE) # dodanie legendy
}
hc

### Edycja wizualna
# Dodanie tytułu
hc <- hc %>% 
  hc_title(text = "Krzywa Phillipsa",
           margin = 20, align = "left")
hc

# Dodanie podtytułu
hc <- hc %>% 
  hc_subtitle(text = "na podstawie danych z Index of Economic Freedom", # wyświetlany tekst
              align = "left", # położenie
              style = list(color = 'blue', fontWeight = "bold")) # styl(kolor, opcje czcionki)
hc

# Dodanie napisu pod wykresem z linkiem
hc <- hc %>% 
  hc_credits(enabled = TRUE, # dodanie podpisu pod wykresem z linkiem
             text = "www.heritage.org/index",
             href = "http://www.heritage.org/index/") 
hc
# Etykiety osi
hc <- hc %>% 
  hc_xAxis(title = list(text = "Bezrobocie")) %>% # tytuł osi OX
  hc_yAxis(title = list(text = "Inflacja")) # tytuł osi OY
hc

# Podświetlony tekst dla danego państwa.
hc <- hc %>% 
  hc_tooltip(useHTML = TRUE,
             headerFormat = "<table>",  # tekst wyświetlający się po najechaniu kursorem
             pointFormat = paste("<tr><th colspan=\"1\"><b>{point.label}</b></th></tr>",
                                 "<tr><th>Bezrobocie</th><td>{point.x} %</td></tr>",
                                 "<tr><th>Inflacja</th><td>{point.y} %</td></tr>",
                                 "<tr><th>Populacja</th><td>{point.z} mln</td></tr>",
                                 "<tr><th>panstwo</th><td>{baza2.name} mln</td></tr>"),
             footerFormat = "</table>",
              followPointer= TRUE)

# w znacznikach:
# <tr> wiersz tabeli </tr>
# <th> komórki nagłówkowe </th>
# <td> komórki danych </td>
hc 

### Inny przykład

# Rozbudowany wykres
cols <- c('#0431B4','#A901DB','#FF4000')

hc %>% 
  hc_colors(cols) %>%
  hc_xAxis(plotLines = list(
    list(label = list(text = "plotLine"),
         color = "green",
         width = 2,
         value = 5.5))) %>% #plotline
  hc_yAxis(title = list(text = "Temperature"),
           minorTickInterval = "auto",  
           minorGridLineDashStyle = "LongDashDotDot",  #tło
           plotBands = list(
             list(from = 25, to = JS("Infinity"), color = "rgba(100, 0, 0, 0.1)",
                  label = list(text = "plotBand"))))%>% # plotBand
  hc_title(text = "Klimat",
           margin = 20, align = "left",
           style = list(color = "#90ed7d", useHTML = TRUE)) %>% #tytuł 
  hc_subtitle(text = "W wielkich metropoliach",
              align = "left",
              style = list(color = "#2b908f", fontWeight = "bold"))  %>%  #podtytuł
  hc_legend(align = "left", verticalAlign = "top",
            layout = "vertical", x = 0, y = 100) %>% #legenda
  hc_tooltip(crosshairs = TRUE, backgroundColor = "#FCFFC5",
             shared = TRUE, borderWidth = 5) #%>%#stworzenie pola umożliwiającego równoczesne odczytywanie temperatur dla wszystkich miast 

# Zmiana aspektów estetycznych
#hc %>% 
  hc_chart(borderColor = '#EBBA95',  # kolor krawędzi
           borderRadius = 10,  #zaokrąglenie krawędzi
           borderWidth = 2,    #szerokość krawędzi
           backgroundColor = list(
             linearGradient = c(0, 0, 500, 500),
             #określanie współrzędnych, dla których osiągnięty będą kolory z listy
             stops = list(
               list(0, 'rgb(0, 0, 0)'),
               list(1, 'rgb(200, 200, 255)')
             )))

hc %>% 
  hc_add_theme(hc_theme_economist())
