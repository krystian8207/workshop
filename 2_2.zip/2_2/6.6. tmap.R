###########################################################
#       Analiza i wizualizacja danych w programie R       #
#                        LabMasters                       #
#                     Piotr Ćwiakowski                    #
#                       pakiet tmap                       #
###########################################################


# Instalacja pakietów
# install.packages("sp")
# install.packages('tmap')
# install.packages('plyr')
# install.packages("knitr")
# install.packages("RPostgreSQL")

# Wczytanie bibliotek
library(sp)
library(tmap)
library(plyr)
library(knitr)

# Ścieżka dostępu
setwd('...')

# Wczytanie i przygotowanie danych
data(World, metro)

baza<-read.csv('State.csv',header=T,dec=".",sep=',',stringsAsFactors = FALSE)

# MAPA 1
# Dopisanie interesującej nas zmiennej do danych przestrzennych

World$Podatki <- baza$podatki

# Mapa - wpływy podatkowe do PKB
mapWorld1<- tm_shape(World) +
  tm_polygons("Podatki", palette="BuPu", contrast=.7, id="name", title="Wpływy podatkowe do PKB")

# W trybie nie interaktywnym:
mapWorld1

# set mode to view:
tmap_mode("view")

# Tryb interaktywny
mapWorld1


# MAPA 2
# Dodanie mapowania zmiennej będącej indeksem wolnosci gospodarczej.
# Dodajmy punkty w środkach państw. Ich wielkość będzie prezentowała wysokość wskaźnika.

# Policzenie środków dla Państw
srodki <- coordinates(World)

# wstawienie danych ekonomicznych do bazy danych przestrzennych
przestrzenne1<-SpatialPointsDataFrame(srodki, # Poniżej system koortdynatów które używamy:
                                      proj4string=CRS('+proj=eck4 +lon_0=0 +x_0=0 +y_0=0 +ellps=WGS84 +datum=WGS84 +units=m +no_defs +towgs84=0,0,0 '),
                                      data.frame(Indeks = baza$indeksWolnosci # dokładne miejsce na wstawienie danych
                                      )) 

# Mapa - wpływy podatkowe do PKB + indeks wolności gospodarczej

# generowanie mapy
mapWorld2 <- tm_shape(World) +
  tm_polygons("Podatki", palette="BuPu", contrast=.7, id="name", title="Wpływy podatkowe do PKB") +
  tm_shape(przestrzenne1) +
  tm_bubbles(size="Indeks", col='yellow',
             border.col = "black", border.alpha = .5,
             title.size="Indeks wolności gospodarczej", id="name") + 
  tm_style_gray() + tm_format_World()

mapWorld2

# MAPA 3
# Dodanie mapowania zmiennej oznaczającej ustroj państwa.

# połączenie centroidów(środków państw) ze zmiennymi
przestrzenne2<-SpatialPointsDataFrame(srodki, # Poniżej system koortdynatów które używamy:
                               proj4string=CRS('+proj=eck4 +lon_0=0 +x_0=0 +y_0=0 +ellps=WGS84 +datum=WGS84 +units=m +no_defs +towgs84=0,0,0 '),
                               data.frame(Indeks = baza$indeksWolnosci,# dokładne miejsce na wstawienie danych
                                          Ustroj=baza$ustroj))

# generowanie mapy
mapWorld3 <- tm_shape(World) +
  tm_polygons("Podatki", palette="BuPu", contrast=.7, id="name", title="Wpływy podatkowe do PKB") +
  tm_shape(przestrzenne2) +
  tm_bubbles(size="Indeks", col="Ustroj",
             border.col = "black", border.alpha = .5, 
             palette="RdYlBu",labels=c('autokracja', 'anokracja', 'demokracja'),
             contrast=0.7,
             title.size="Indeks wolności gospodarczej", 
             title.col="Ustrój państwa", id="name") + 
  tm_style_gray() + tm_format_World()

mapWorld3

# Więcej informacji:
# https://cran.r-project.org/web/packages/tmap/vignettes/tmap-nutshell.html
# https://github.com/mtennekes/tmap
