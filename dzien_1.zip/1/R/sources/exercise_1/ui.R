library(plotly)

ui <- fluidPage(
  titlePanel("Ceny wynajmu mieszkań w funkcji metrażu w Warszawie"),
  h4("Rozwiązanie statyczne + konwersja"),
  plotlyOutput("stc"),
  br(),
  h4("Rozwiązanie dynamiczne"),
  plotlyOutput("dyn")
)
