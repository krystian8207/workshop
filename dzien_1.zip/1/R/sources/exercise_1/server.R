library(plotly)
library(tidyverse)

data <- readRDS("data/gumtree.rds") %>%
  head(1000)

server <- function(input, output, session) {
  # Rozwiązanie statyczne + konwersja
  output$stc <- renderPlotly({
    gg_plt <- data %>%
      ggplot(aes(x = wielkosc_m2, y = cena, color = liczba_pokoi)) +
      geom_point() +
      xlab("Wielkość [m2]") +
      ylab("Cena [PLN]") +
      ggtitle("Ceny mieszkań w funkcji ich rozmiaru",
              subtitle = "z uwzględnieniem liczby pokoi") +
      theme(plot.title = element_text(hjust = 0.5),
            plot.subtitle = element_text(hjust = 0.5))
    
    ggplotly(gg_plt)
  })
  
  # Rozwiązanie dynamiczne
  output$dyn <- renderPlotly({
    data %>%
      plot_ly(x = ~wielkosc_m2, y = ~cena, color = ~liczba_pokoi,
              type = "scatter", mode = "markers") %>%
      layout(title = str_c("Ceny mieszkań w funkcji ich rozmiaru",
                           "z uwzględnieniem liczby pokoi",
                           sep = "<br>"),
             xaxis = list(title = str_c("Wielkość [m", tags$sup("2"), "]")),
             yaxis = list(title = "Cena [PLN]"))
  })
}
