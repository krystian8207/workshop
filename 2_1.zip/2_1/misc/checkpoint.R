# checkpoint::checkpoint("2018-08-01")
checkpoint::checkpoint("2019-01-01", scanForPackages = FALSE)
